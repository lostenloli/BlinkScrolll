import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.blinkscroll"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.blinkscroll"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
    }

    // Постоянный ключ подписи: новые версии ставятся поверх старой без удаления
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    // Модель MediaPipe должна лежать в APK несжатой
    androidResources {
        noCompress.add("task")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.activity:activity-ktx:1.9.1")

    val camerax = "1.3.4"
    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")

    // MediaPipe Face Landmarker: радужка, направление взгляда, моргание, поворот головы
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Скачиваем модель лица (~4 МБ) при сборке, если её ещё нет. На GitHub это делается само.
val faceModel = file("src/main/assets/face_landmarker.task")
val downloadFaceModel by tasks.registering {
    outputs.file(faceModel)
    doLast {
        if (!faceModel.exists()) {
            faceModel.parentFile.mkdirs()
            val url = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
            URL(url).openStream().use { input ->
                faceModel.outputStream().use { output -> input.copyTo(output) }
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadFaceModel) }
