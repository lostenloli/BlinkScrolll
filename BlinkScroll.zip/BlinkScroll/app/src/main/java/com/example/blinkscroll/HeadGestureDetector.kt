package com.example.blinkscroll

import kotlin.math.abs

enum class HeadGesture { UP, DOWN, LEFT, RIGHT, TILT_LEFT, TILT_RIGHT }

/**
 * Жесты головой относительно "спокойной" позы.
 *
 * Поза запоминается сама и медленно подстраивается, пока голова в покое.
 * Жест срабатывает, если голову отвели дальше порога и подержали [holdMs].
 * Следующий жест возможен только после возврата в спокойную позу.
 */
class HeadGestureDetector(private val onGesture: (HeadGesture) -> Unit) {

    /** true — реагировать только на наклоны к плечу (для режима курсора) */
    var rollOnly = false

    private val turnThreshold = 12f   // градусы для поворота и кивка
    private val rollThreshold = 15f   // градусы для наклона к плечу
    private val neutralZone = 6f
    private val holdMs = 200L

    private var base: FloatArray? = null // pitch, yaw, roll
    private var pending: HeadGesture? = null
    private var pendingSince = 0L
    private var armed = true

    fun reset() {
        base = null
        pending = null
        armed = true
    }

    fun update(pitch: Float, yaw: Float, roll: Float, now: Long) {
        val b = base ?: floatArrayOf(pitch, yaw, roll).also { base = it }
        val dp = if (rollOnly) 0f else pitch - b[0]
        val dy = if (rollOnly) 0f else yaw - b[1]
        val dr = roll - b[2]

        if (maxOf(abs(dp), abs(dy), abs(dr)) < neutralZone) {
            armed = true
            pending = null
            // Голова в покое — медленно подстраиваемся под позу (лёг, сел и т.д.)
            b[0] += (pitch - b[0]) * 0.05f
            b[1] += (yaw - b[1]) * 0.05f
            b[2] += (roll - b[2]) * 0.05f
            return
        }
        if (!armed) return

        val g = when {
            abs(dr) >= rollThreshold && abs(dr) > abs(dy) ->
                if (dr > 0) HeadGesture.TILT_LEFT else HeadGesture.TILT_RIGHT
            abs(dy) >= turnThreshold && abs(dy) >= abs(dp) ->
                if (dy > 0) HeadGesture.LEFT else HeadGesture.RIGHT
            abs(dp) >= turnThreshold ->
                if (dp > 0) HeadGesture.UP else HeadGesture.DOWN
            else -> null
        }

        if (g == null) {
            pending = null
            return
        }
        if (g != pending) {
            pending = g
            pendingSince = now
            return
        }
        if (now - pendingSince >= holdMs) {
            armed = false
            pending = null
            onGesture(g)
        }
    }
}
