package com.example.blinkscroll

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

/** Делает жесты пальцем, системные "Назад"/"Домой" и рисует курсор поверх экрана. */
class ScrollAccessibilityService : AccessibilityService() {

    private var cursorView: View? = null
    private var cursorParams: WindowManager.LayoutParams? = null
    private var cursorSize = 0

    private var statusView: TextView? = null
    private var statusColor = 0

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideCursor()
        hideStatus()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    // ---------- размеры экрана ----------

    fun screenWidth(): Int = screenSize().first
    fun screenHeight(): Int = screenSize().second

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    // ---------- жесты ----------

    private fun stroke(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /** Палец снизу вверх — следующее видео */
    fun swipeUp() {
        val w = screenWidth(); val h = screenHeight()
        stroke(w / 2f, h * 0.75f, w / 2f, h * 0.25f, 220)
    }

    /** Палец сверху вниз — предыдущее видео */
    fun swipeDown() {
        val w = screenWidth(); val h = screenHeight()
        stroke(w / 2f, h * 0.25f, w / 2f, h * 0.75f, 220)
    }

    /** Палец справа налево — следующая сторис / фото */
    fun swipeLeft() {
        val w = screenWidth(); val h = screenHeight()
        stroke(w * 0.85f, h / 2f, w * 0.15f, h / 2f, 220)
    }

    /** Палец слева направо */
    fun swipeRight() {
        val w = screenWidth(); val h = screenHeight()
        stroke(w * 0.15f, h / 2f, w * 0.85f, h / 2f, 220)
    }

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)

    // ---------- курсор ----------

    fun showCursor() {
        if (cursorView != null) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cursorSize = (28 * resources.displayMetrics.density).toInt()

        val view = object : View(this) {
            private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(150, 255, 64, 129)
            }
            private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 4f
                color = Color.WHITE
            }

            override fun onDraw(canvas: Canvas) {
                val r = width / 2f
                canvas.drawCircle(r, r, r - 4f, fill)
                canvas.drawCircle(r, r, r - 4f, ring)
            }
        }

        val params = WindowManager.LayoutParams(
            cursorSize,
            cursorSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth() / 2 - cursorSize / 2
            y = screenHeight() / 2 - cursorSize / 2
        }

        wm.addView(view, params)
        cursorView = view
        cursorParams = params
    }

    fun moveCursor(x: Float, y: Float) {
        val view = cursorView ?: return
        val params = cursorParams ?: return
        params.x = (x - cursorSize / 2f).toInt()
        params.y = (y - cursorSize / 2f).toInt()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.updateViewLayout(view, params)
    }

    fun hideCursor() {
        val view = cursorView ?: return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try {
            wm.removeView(view)
        } catch (e: Exception) {
        }
        cursorView = null
        cursorParams = null
    }

    // ---------- плавающий индикатор ----------

    /** Показать/обновить плашку вверху экрана. Касания проходят сквозь неё. */
    fun showStatus(text: String, color: Int) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var view = statusView
        if (view == null) {
            val d = resources.displayMetrics.density
            view = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 14f
                setPadding((14 * d).toInt(), (6 * d).toInt(), (14 * d).toInt(), (6 * d).toInt())
            }
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = (40 * d).toInt()
            }
            try {
                wm.addView(view, params)
            } catch (e: Exception) {
                return
            }
            statusView = view
            statusColor = 0
        }
        if (view.text.toString() != text) view.text = text
        if (color != statusColor) {
            statusColor = color
            view.background = GradientDrawable().apply {
                cornerRadius = 1000f
                setColor(color)
            }
        }
    }

    fun hideStatus() {
        val view = statusView ?: return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try {
            wm.removeView(view)
        } catch (e: Exception) {
        }
        statusView = null
    }

    companion object {
        @Volatile
        var instance: ScrollAccessibilityService? = null
    }
}
