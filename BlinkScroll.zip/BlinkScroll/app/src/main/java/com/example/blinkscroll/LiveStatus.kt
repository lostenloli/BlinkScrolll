package com.example.blinkscroll

/** Общие данные между сервисом камеры и экранами приложения. */
object LiveStatus {
    /** Текст для главного экрана: что камера видит прямо сейчас */
    @Volatile
    var face: String = "Камера выключена"

    @Volatile
    var lastGesture: String = "—"

    /** Последние признаки: [взгляд по горизонтали, по вертикали, закрытость глаз, кивок, поворот, наклон] */
    @Volatile
    var features: FloatArray? = null

    @Volatile
    var faceVisible = false

    /** Во время калибровки жесты не выполняются */
    @Volatile
    var calibrating = false

    /** Меняется, когда сохранили калибровку или сменили профиль — сервис перечитывает настройки */
    @Volatile
    var calibVersion = 0
}
