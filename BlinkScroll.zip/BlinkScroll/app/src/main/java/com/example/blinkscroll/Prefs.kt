package com.example.blinkscroll

import android.content.Context

/** Настройки из главного экрана. Сервис читает их на лету. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("blinkscroll", Context.MODE_PRIVATE)

    /** Наклоны головы к плечам: «Назад» / «Домой» */
    var headGestures: Boolean
        get() = sp.getBoolean("head", true)
        set(v) = sp.edit().putBoolean("head", v).apply()

    /** Плавающий индикатор слежения поверх экрана */
    var overlay: Boolean
        get() = sp.getBoolean("overlay", true)
        set(v) = sp.edit().putBoolean("overlay", v).apply()

    /** Сколько миллисекунд держать глаза закрытыми, чтобы моргание засчиталось */
    var blinkMinMs: Int
        get() = sp.getInt("blinkMin", 250)
        set(v) = sp.edit().putInt("blinkMin", v).apply()

    /** Текущий профиль: в очках или без */
    var glasses: Boolean
        get() = sp.getBoolean("glasses", false)
        set(v) = sp.edit().putBoolean("glasses", v).apply()

    fun hasCalibration(): Boolean = sp.contains(calibKey())

    fun calibration(): Calibration =
        Calibration.parse(sp.getString(calibKey(), null)) ?: Calibration.DEFAULT

    fun saveCalibration(c: Calibration) {
        sp.edit().putString(calibKey(), c.serialize()).apply()
    }

    private fun calibKey() = if (glasses) "calib_glasses" else "calib_plain"
}
