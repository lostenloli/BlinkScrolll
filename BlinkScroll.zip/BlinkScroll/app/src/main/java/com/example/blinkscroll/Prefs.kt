package com.example.blinkscroll

import android.content.Context

/** Настройки из главного экрана. Сервис читает их на лету. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("blinkscroll", Context.MODE_PRIVATE)

    /** Жесты головой в режиме листания */
    var headGestures: Boolean
        get() = sp.getBoolean("head", true)
        set(v) = sp.edit().putBoolean("head", v).apply()

    /** Поменять лево/право, если повороты головы работают зеркально */
    var swapSides: Boolean
        get() = sp.getBoolean("swap", false)
        set(v) = sp.edit().putBoolean("swap", v).apply()

    /** Сколько миллисекунд держать глаза закрытыми (или опущенными) для срабатывания */
    var blinkMinMs: Int
        get() = sp.getInt("blinkMin", 300)
        set(v) = sp.edit().putInt("blinkMin", v).apply()
}
