package com.example.blinkscroll

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) startBlinkService()
            else Toast.makeText(this, "Без камеры моргания не увидеть", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        status = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, pad) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(status)
            addView(button("1. Включить спецвозможность BlinkScroll") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(button("2. Старт") { requestAndStart() })
            addView(button("Стоп") {
                startService(
                    Intent(this@MainActivity, BlinkCameraService::class.java)
                        .setAction(BlinkCameraService.ACTION_STOP)
                )
                window.decorView.postDelayed({ refresh() }, 300)
            })
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val a11y = if (ScrollAccessibilityService.instance != null) "✅" else "❌"
        val cam = if (BlinkCameraService.isRunning) "✅" else "❌"
        status.text = "Спецвозможность: $a11y\nКамера следит: $cam\n\n" +
            "Откройте рилсы и медленно моргните (~полсекунды), чтобы перейти к следующему."
    }

    private fun requestAndStart() {
        val needed = buildList {
            add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isEmpty()) startBlinkService() else askPermissions.launch(needed.toTypedArray())
    }

    private fun startBlinkService() {
        ContextCompat.startForegroundService(this, Intent(this, BlinkCameraService::class.java))
        window.decorView.postDelayed({ refresh() }, 300)
        if (ScrollAccessibilityService.instance == null) {
            Toast.makeText(this, "Не забудьте включить спецвозможность (шаг 1)", Toast.LENGTH_LONG).show()
        }
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }
}
