package com.example.blinkscroll

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var prefs: Prefs

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) startBlinkService()
            else Toast.makeText(this, "Без камеры лица не увидеть", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val pad = (20 * resources.displayMetrics.density).toInt()
        status = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, pad) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(status)

            addView(button("1. Включить спецвозможность BlinkScroll") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(button("2. Старт") { requestAndStart() })
            addView(button("Стоп") {
                startService(
                    Intent(this@MainActivity, BlinkCameraService::class.java)
                        .setAction(BlinkCameraService.ACTION_STOP)
                )
                window.decorView.postDelayed({ refresh() }, 300)
            })

            addView(header("Настройки", pad))
            addView(CheckBox(this@MainActivity).apply {
                text = "Жесты головой (повороты, кивок вверх, наклоны)"
                isChecked = prefs.headGestures
                setOnCheckedChangeListener { _, v -> prefs.headGestures = v }
            })
            addView(CheckBox(this@MainActivity).apply {
                text = "Поменять лево и право (если путает стороны)"
                isChecked = prefs.swapSides
                setOnCheckedChangeListener { _, v -> prefs.swapSides = v }
            })

            val blinkLabel = TextView(this@MainActivity).apply { setPadding(0, pad / 2, 0, 0) }
            fun updateBlinkLabel() {
                blinkLabel.text = "Моргание / взгляд вниз: держать ${prefs.blinkMinMs} мс"
            }
            updateBlinkLabel()
            addView(blinkLabel)
            addView(SeekBar(this@MainActivity).apply {
                max = 600 // 200..800 мс
                progress = prefs.blinkMinMs - 200
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        prefs.blinkMinMs = 200 + p
                        updateBlinkLabel()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) = Unit
                    override fun onStopTrackingTouch(s: SeekBar?) = Unit
                })
            })

            addView(header("Жесты", pad))
            addView(TextView(this@MainActivity).apply {
                textSize = 15f
                text = """
                    Режим листания:
                    • Медленно моргнуть или опустить взгляд — следующее видео
                    • Задрать подбородок — предыдущее видео
                    • Повернуть голову вправо / влево — свайп вбок (сторис, фото)
                    • Наклонить голову к левому плечу — «Назад»
                    • Наклонить к правому плечу — «Домой»

                    Закрыть глаза на 2 секунды — переключить режим.

                    Режим курсора:
                    • Двигайте головой — точка ходит по экрану
                    • Медленно моргнуть — нажать под точкой
                    • Наклоны к плечам — «Назад» / «Домой»

                    Перед жестом головой держите её ровно секунду — приложение
                    запоминает спокойную позу.
                """.trimIndent()
            })
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val a11y = if (ScrollAccessibilityService.instance != null) "✅" else "❌"
        val cam = if (BlinkCameraService.isRunning) "✅" else "❌"
        status.text = "Спецвозможность: $a11y\nКамера следит: $cam"
    }

    private fun requestAndStart() {
        val needed = buildList {
            add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isEmpty()) startBlinkService() else askPermissions.launch(needed.toTypedArray())
    }

    private fun startBlinkService() {
        ContextCompat.startForegroundService(this, Intent(this, BlinkCameraService::class.java))
        window.decorView.postDelayed({ refresh() }, 300)
        if (ScrollAccessibilityService.instance == null) {
            Toast.makeText(this, "Не забудьте включить спецвозможность (шаг 1)", Toast.LENGTH_LONG).show()
        }
    }

    private fun header(text: String, pad: Int) = TextView(this).apply {
        this.text = text
        textSize = 20f
        setPadding(0, pad, 0, pad / 3)
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }
}
