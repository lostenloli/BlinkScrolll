package com.example.blinkscroll

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var live: TextView
    private lateinit var prefs: Prefs

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (result[Manifest.permission.CAMERA] == true) startBlinkService()
            else Toast.makeText(this, "Без камеры лица не увидеть", Toast.LENGTH_LONG).show()
        }

    // Обновляем живые показания 5 раз в секунду
    private val ticker = object : Runnable {
        override fun run() {
            live.text = "Камера видит:\n${LiveStatus.face}\n\nПоследний жест: ${LiveStatus.lastGesture}"
            live.postDelayed(this, 200)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val pad = (20 * resources.displayMetrics.density).toInt()
        status = TextView(this).apply { textSize = 17f; setPadding(0, 0, 0, pad / 2) }
        live = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, pad / 2) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(status)

            addView(button("1. Включить спецвозможность BlinkScroll") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
            addView(button("2. Старт") { requestAndStart() })
            addView(button("3. Калибровка под моё лицо") {
                startActivity(Intent(this@MainActivity, CalibrationActivity::class.java))
            })
            addView(button("Стоп") {
                startService(
                    Intent(this@MainActivity, BlinkCameraService::class.java)
                        .setAction(BlinkCameraService.ACTION_STOP)
                )
                window.decorView.postDelayed({ refresh() }, 300)
            })

            addView(live)

            addView(header("Настройки", pad))
            addView(CheckBox(this@MainActivity).apply {
                text = "Я сейчас в очках (отдельная калибровка)"
                isChecked = prefs.glasses
                setOnCheckedChangeListener { _, v ->
                    prefs.glasses = v
                    LiveStatus.calibVersion++
                    refresh()
                }
            })
            addView(CheckBox(this@MainActivity).apply {
                text = "Наклоны головы к плечам: «Назад» / «Домой»"
                isChecked = prefs.headGestures
                setOnCheckedChangeListener { _, v -> prefs.headGestures = v }
            })

            val blinkLabel = TextView(this@MainActivity).apply { setPadding(0, pad / 2, 0, 0) }
            fun updateBlinkLabel() {
                blinkLabel.text = "Медленное моргание: держать глаза закрытыми ${prefs.blinkMinMs} мс"
            }
            updateBlinkLabel()
            addView(blinkLabel)
            addView(SeekBar(this@MainActivity).apply {
                max = 600 // 200..800 мс
                progress = prefs.blinkMinMs - 200
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        prefs.blinkMinMs = 200 + p
                        updateBlinkLabel()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) = Unit
                    override fun onStopTrackingTouch(s: SeekBar?) = Unit
                })
            })

            addView(header("Жесты", pad))
            addView(TextView(this@MainActivity).apply {
                textSize = 15f
                text = """
                    Режим листания (только глазами):
                    • Взгляд вниз — следующее видео
                    • Взгляд вверх — предыдущее видео
                    • Взгляд вправо / влево — свайп вбок (сторис, фото)
                    • Медленно моргнуть — тоже следующее видео
                    • Наклон головы к левому плечу — «Назад»
                    • Наклон к правому плечу — «Домой»

                    Закрыть глаза на 2 секунды — переключить режим.

                    Режим курсора (головой):
                    • Двигайте головой — розовая точка ходит по экрану
                    • Медленно моргнуть — нажать под точкой
                    • Наклоны к плечам — «Назад» / «Домой»

                    Совет: пройдите калибровку в том положении, в котором
                    обычно листаете (лёжа, сидя), и при похожем свете.
                """.trimIndent()
            })
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
        live.post(ticker)
    }

    override fun onPause() {
        live.removeCallbacks(ticker)
        super.onPause()
    }

    private fun refresh() {
        val a11y = if (ScrollAccessibilityService.instance != null) "✅" else "❌"
        val cam = if (BlinkCameraService.isRunning) "✅" else "❌"
        val profile = if (prefs.glasses) "в очках" else "без очков"
        val calib = if (prefs.hasCalibration()) "✅" else "❌ (нажмите «Калибровка»)"
        status.text = "Спецвозможность: $a11y\nКамера следит: $cam\nКалибровка ($profile): $calib"
    }

    private fun requestAndStart() {
        val needed = buildList {
            add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isEmpty()) startBlinkService() else askPermissions.launch(needed.toTypedArray())
    }

    private fun startBlinkService() {
        ContextCompat.startForegroundService(this, Intent(this, BlinkCameraService::class.java))
        window.decorView.postDelayed({ refresh() }, 300)
        if (ScrollAccessibilityService.instance == null) {
            Toast.makeText(this, "Не забудьте включить спецвозможность (шаг 1)", Toast.LENGTH_LONG).show()
        }
    }

    private fun header(text: String, pad: Int) = TextView(this).apply {
        this.text = text
        textSize = 20f
        setPadding(0, pad, 0, pad / 3)
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }
}
