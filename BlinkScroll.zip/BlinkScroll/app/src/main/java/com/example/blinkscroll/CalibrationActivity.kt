package com.example.blinkscroll

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat

/**
 * Калибровка под ваше лицо: по очереди просим посмотреть в разные стороны,
 * закрыть глаза и подвигать головой, и запоминаем, как это выглядит у вас.
 */
class CalibrationActivity : ComponentActivity() {

    private class Step(val text: String, val dotGravity: Int?)

    private val steps = listOf(
        // Первые 6 шагов — в порядке EyeState: CENTER, UP, DOWN, LEFT, RIGHT, CLOSED
        Step("Смотрите на точку в центре.\nГолову держите как обычно.", Gravity.CENTER),
        Step("Только глазами — на точку ВВЕРХУ.\nГолову не двигайте.", Gravity.TOP or Gravity.CENTER_HORIZONTAL),
        Step("Только глазами — на точку ВНИЗУ.\nГолову не двигайте.", Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL),
        Step("Только глазами — ВЛЕВО,\nза край экрана.\nГолову не двигайте.", Gravity.START or Gravity.CENTER_VERTICAL),
        Step("Только глазами — ВПРАВО,\nза край экрана.\nГолову не двигайте.", Gravity.END or Gravity.CENTER_VERTICAL),
        Step("Закройте глаза и не открывайте,\nпока телефон не вибрирует.", null),
        // Дальше — голова, чтобы понять, где у камеры ваше лево и верх
        Step("Поверните ГОЛОВУ влево\n(глаза — куда удобно).", null),
        Step("Поднимите ПОДБОРОДОК вверх.", null),
        Step("Наклоните голову к ЛЕВОМУ плечу.", null),
    )

    private val handler = Handler(Looper.getMainLooper())
    private val results = ArrayList<FloatArray>()
    private var stepIndex = 0

    private lateinit var titleView: TextView
    private lateinit var instruction: TextView
    private lateinit var dot: View
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Сначала нажмите «Старт» и разрешите камеру", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (!BlinkCameraService.isRunning) {
            ContextCompat.startForegroundService(this, Intent(this, BlinkCameraService::class.java))
        }
        LiveStatus.calibrating = true

        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()

        titleView = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        instruction = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val dotSize = (36 * density).toInt()
        dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(255, 64, 129))
            }
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            setPadding(pad, pad * 3, pad, pad * 3)
            addView(dot, FrameLayout.LayoutParams(dotSize, dotSize, Gravity.CENTER))
            addView(
                titleView,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP,
                ).apply { topMargin = pad * 4 },
            )
            addView(
                instruction,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER,
                ).apply { topMargin = pad * 8 },
            )
        }
        setContentView(root)

        val profile = if (prefs.glasses) "в очках" else "без очков"
        titleView.text = "Калибровка (профиль: $profile)"
        instruction.text = "Держите телефон как обычно,\nкогда листаете.\n\nНачинаем через 3 секунды…"
        dot.visibility = View.INVISIBLE
        handler.postDelayed({ showStep() }, 3000)
    }

    private fun showStep() {
        val step = steps[stepIndex]
        titleView.text = "Шаг ${stepIndex + 1} из ${steps.size}"
        instruction.text = step.text
        val g = step.dotGravity
        if (g == null) {
            dot.visibility = View.INVISIBLE
        } else {
            dot.visibility = View.VISIBLE
            (dot.layoutParams as FrameLayout.LayoutParams).gravity = g
            dot.requestLayout()
        }
        // Даём 1.8 секунды занять позу, потом 1.5 секунды записываем
        handler.postDelayed({ collect(ArrayList(), System.currentTimeMillis()) }, 1800)
    }

    private fun collect(samples: ArrayList<FloatArray>, start: Long) {
        val f = LiveStatus.features
        if (LiveStatus.faceVisible && f != null) samples.add(f.copyOf())

        if (System.currentTimeMillis() - start < 1500) {
            handler.postDelayed({ collect(samples, start) }, 50)
            return
        }

        if (samples.size < 8) {
            instruction.text = "Лицо плохо видно 🙁\nДержите телефон напротив лица.\nПовторяем…"
            handler.postDelayed({ showStep() }, 1500)
            return
        }

        val avg = FloatArray(6)
        for (s in samples) for (i in 0 until 6) avg[i] += s[i] / samples.size
        results.add(avg)
        vibrate()

        stepIndex++
        if (stepIndex < steps.size) {
            instruction.text = "✓"
            dot.visibility = View.INVISIBLE
            handler.postDelayed({ showStep() }, 600)
        } else {
            finishCalibration()
        }
    }

    private fun finishCalibration() {
        // Образцы глаз: [горизонталь, вертикаль, закрытость] для первых 6 шагов
        val centroids = Array(6) { i -> floatArrayOf(results[i][0], results[i][1], results[i][2]) }

        // Знаки головы: делаем так, чтобы "влево", "вверх" и "к левому плечу" были положительными
        val center = results[0]
        val yawSign = if (results[6][4] - center[4] >= 0) 1f else -1f
        val pitchSign = if (results[7][3] - center[3] >= 0) 1f else -1f
        val rollSign = if (results[8][5] - center[5] >= 0) 1f else -1f

        prefs.saveCalibration(Calibration(centroids, yawSign, pitchSign, rollSign))
        LiveStatus.calibVersion++

        dot.visibility = View.INVISIBLE
        titleView.text = "Готово"
        instruction.text = "Калибровка сохранена ✅\n\nПроверьте на главном экране:\nв строке «Взгляд» должно\nменяться направление."
        handler.postDelayed({ finish() }, 2500)
    }

    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        LiveStatus.calibrating = false
        super.onDestroy()
    }
}
