package com.example.blinkscroll

/**
 * Превращает поток состояний глаз в события.
 *
 * - [onEnter] — взгляд перешёл в новое состояние (вверх, вниз, прямо...).
 * - [onBlink] — глаза были закрыты от [minBlinkMs] до [maxBlinkMs] и открылись.
 *   Передаётся момент, когда глаза закрылись.
 * - [onLongClose] — глаза закрыты дольше [longCloseMs] (сразу, не дожидаясь открытия).
 *
 * Новое состояние принимается, только если продержалось 2 кадра подряд — так
 * случайные скачки распознавания не ломают жесты.
 */
class EyeGestureDetector(
    var minBlinkMs: Long = 250,
    private val maxBlinkMs: Long = 1500,
    private val longCloseMs: Long = 2000,
    private val onEnter: (EyeState, Long) -> Unit,
    private val onBlink: (Long) -> Unit,
    private val onLongClose: () -> Unit,
) {
    var state = EyeState.CENTER
        private set

    private var since = 0L
    private var longFired = false
    private var candidate = EyeState.CENTER
    private var candidateFrames = 0

    fun reset() {
        state = EyeState.CENTER
        longFired = false
        candidate = EyeState.CENTER
        candidateFrames = 0
    }

    fun update(raw: EyeState, now: Long) {
        if (raw == state) {
            candidateFrames = 0
            checkLong(now)
            return
        }

        if (raw == candidate) {
            candidateFrames++
        } else {
            candidate = raw
            candidateFrames = 1
        }
        if (candidateFrames < 2) {
            checkLong(now)
            return
        }

        // Состояние сменилось
        if (state == EyeState.CLOSED && !longFired) {
            val closedFor = now - since
            if (closedFor in minBlinkMs..maxBlinkMs) onBlink(since)
        }
        state = raw
        since = now
        longFired = false
        candidateFrames = 0
        onEnter(raw, now)
    }

    private fun checkLong(now: Long) {
        if (state == EyeState.CLOSED && !longFired && now - since >= longCloseMs) {
            longFired = true
            onLongClose()
        }
    }
}
