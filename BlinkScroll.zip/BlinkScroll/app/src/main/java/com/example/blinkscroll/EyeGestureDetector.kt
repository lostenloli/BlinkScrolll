package com.example.blinkscroll

/**
 * Превращает поток состояний глаз в жесты.
 *
 * - Взгляд вверх/вниз/влево/вправо держится [gazeHoldMs] → [onGaze] (один раз,
 *   следующий — только после возврата взгляда).
 * - Глаза закрыты от [minBlinkMs] до [maxBlinkMs] и открылись → [onSlowBlink].
 * - Глаза закрыты дольше [longCloseMs] → [onLongClose] сразу.
 *
 * Новое состояние принимается, только если продержалось 2 кадра подряд — так
 * случайные скачки распознавания не ломают жесты.
 */
class EyeGestureDetector(
    var minBlinkMs: Long = 300,
    private val maxBlinkMs: Long = 1500,
    private val longCloseMs: Long = 2000,
    private val gazeHoldMs: Long = 300,
    private val onGaze: (EyeState) -> Unit,
    private val onSlowBlink: () -> Unit,
    private val onLongClose: () -> Unit,
) {
    var state = EyeState.CENTER
        private set

    private var since = 0L
    private var fired = false
    private var candidate = EyeState.CENTER
    private var candidateFrames = 0

    fun reset() {
        state = EyeState.CENTER
        fired = false
        candidate = EyeState.CENTER
        candidateFrames = 0
    }

    fun update(raw: EyeState, now: Long) {
        if (raw == state) {
            candidateFrames = 0
            check(now)
            return
        }

        if (raw == candidate) candidateFrames++ else {
            candidate = raw
            candidateFrames = 1
        }
        if (candidateFrames < 2) {
            check(now)
            return
        }

        // Состояние сменилось
        if (state == EyeState.CLOSED && !fired) {
            val closedFor = now - since
            if (closedFor in minBlinkMs..maxBlinkMs) onSlowBlink()
        }
        state = raw
        since = now
        fired = false
        candidateFrames = 0
    }

    private fun check(now: Long) {
        if (fired) return
        val d = now - since
        when (state) {
            EyeState.CENTER -> Unit
            EyeState.CLOSED -> if (d >= longCloseMs) {
                fired = true
                onLongClose()
            }
            else -> if (d >= gazeHoldMs) {
                fired = true
                onGaze(state)
            }
        }
    }
}
