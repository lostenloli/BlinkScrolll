package com.example.blinkscroll

import kotlin.math.abs
import kotlin.math.max

enum class EyeState { CENTER, UP, DOWN, LEFT, RIGHT, CLOSED }

// Калибровка: [горизонталь, вертикаль, закрытость] для 6 состояний
class Calibration(
    private val c: Array<FloatArray>,
    val yawSign: Float,
    val pitchSign: Float,
    val rollSign: Float,
) {
    // Взгляд влево/вправо выключен: давал ложные свайпы
    var sideGaze = false

    val blinkMid: Float = (c[0][2] + c[5][2]) / 2f

    private var last = EyeState.CENTER

    fun classify(f: FloatArray): EyeState {
        val s = pick(f)
        last = s
        return s
    }

    // Насколько далеко от "прямо" к калиброванной точке: 0 = прямо, 1 = как на калибровке
    private fun progress(value: Float, from: Float, to: Float, fallback: Float): Float {
        var dir = to - from
        if (abs(dir) < 0.02f) dir = fallback
        return (value - from) / dir
    }

    private fun pick(f: FloatArray): EyeState {
        val h = f[0]
        val v = f[1]
        val b = f[2]
        val cen = c[0]
        val up = c[1]
        val dn = c[2]
        val lf = c[3]
        val rt = c[4]
        val cl = c[5]

        // Веки опущены: это либо взгляд вниз, либо глаза закрыты
        if (b > blinkMid) {
            val sv = max(abs(dn[1] - cl[1]), 0.05f)
            val sb = max(abs(dn[2] - cl[2]), 0.05f)
            val toDown = abs(v - dn[1]) / sv + abs(b - dn[2]) / sb
            val toClosed = abs(v - cl[1]) / sv + abs(b - cl[2]) / sb
            return if (toDown < toClosed) EyeState.DOWN else EyeState.CLOSED
        }

        // Порог входа ниже половины пути, порог выхода ещё ниже — меньше дребезга
        fun need(s: EyeState) = if (last == s) 0.3f else 0.45f

        val pUp = progress(v, cen[1], up[1], 0.3f)
        val pDown = progress(v, cen[1], dn[1], -0.3f)
        if (pDown >= need(EyeState.DOWN) && pDown >= pUp) return EyeState.DOWN
        if (pUp >= need(EyeState.UP)) return EyeState.UP

        if (sideGaze) {
            val pL = progress(h, cen[0], lf[0], -0.3f)
            val pR = progress(h, cen[0], rt[0], 0.3f)
            if (pL >= 0.7f && pL > pR) return EyeState.LEFT
            if (pR >= 0.7f) return EyeState.RIGHT
        }
        return EyeState.CENTER
    }

    fun serialize(): String =
        (c.flatMap { it.toList() } + listOf(yawSign, pitchSign, rollSign)).joinToString(",")

    companion object {
        fun parse(s: String?): Calibration? {
            if (s == null) return null
            val v = s.split(",").mapNotNull { it.toFloatOrNull() }
            if (v.size != 21) return null
            val c = Array(6) { i -> floatArrayOf(v[i * 3], v[i * 3 + 1], v[i * 3 + 2]) }
            return Calibration(c, v[18], v[19], v[20])
        }

        val DEFAULT = Calibration(
            arrayOf(
                floatArrayOf(0f, 0f, 0.1f),
                floatArrayOf(0f, 0.4f, 0.05f),
                floatArrayOf(0f, -0.4f, 0.45f),
                floatArrayOf(-0.4f, 0f, 0.1f),
                floatArrayOf(0.4f, 0f, 0.1f),
                floatArrayOf(0f, -0.1f, 0.85f),
            ),
            1f, 1f, 1f,
        )
    }
}
