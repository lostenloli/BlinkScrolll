package com.example.blinkscroll

import kotlin.math.max
import kotlin.math.sqrt

/** Порядок важен: совпадает с первыми шагами калибровки. */
enum class EyeState { CENTER, UP, DOWN, LEFT, RIGHT, CLOSED }

/**
 * Персональная калибровка: как выглядят ВАШИ глаза, когда вы смотрите прямо,
 * вверх, вниз, влево, вправо и когда они закрыты. Каждый кадр относим к
 * ближайшему из этих шести "образцов".
 *
 * Признаки кадра: [взгляд по горизонтали, по вертикали, закрытость глаз].
 * Знаки головы (+1/-1) нужны, чтобы "влево" у курсора всегда было вашим левом.
 */
class Calibration(
    private val centroids: Array<FloatArray>,
    val yawSign: Float,
    val pitchSign: Float,
    val rollSign: Float,
) {
    // Масштаб каждого признака, чтобы ни один не перевешивал
    private val scale = FloatArray(3) { i ->
        val vals = centroids.map { it[i] }
        val mean = vals.average().toFloat()
        val variance = vals.map { (it - mean) * (it - mean) }.average().toFloat()
        max(sqrt(variance), 0.03f)
    }

    /** Середина между "смотрю прямо" и "глаза закрыты" — для заморозки курсора при моргании */
    val blinkMid: Float =
        (centroids[EyeState.CENTER.ordinal][2] + centroids[EyeState.CLOSED.ordinal][2]) / 2f

    fun classify(f: FloatArray): EyeState {
        var best = EyeState.CENTER
        var bestDist = Float.MAX_VALUE
        for (s in EyeState.values()) {
            val d = dist(f, centroids[s.ordinal])
            if (d < bestDist) {
                bestDist = d
                best = s
            }
        }
        // Запас: не-центральное состояние только если оно заметно ближе, чем "прямо"
        if (best != EyeState.CENTER) {
            val toCenter = dist(f, centroids[EyeState.CENTER.ordinal])
            if (bestDist > toCenter * 0.85f) return EyeState.CENTER
        }
        return best
    }

    private fun dist(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in 0 until 3) {
            val d = (a[i] - b[i]) / scale[i]
            sum += d * d
        }
        return sqrt(sum)
    }

    fun serialize(): String =
        (centroids.flatMap { it.toList() } + listOf(yawSign, pitchSign, rollSign)).joinToString(",")

    companion object {
        private const val SIZE = 6 * 3 + 3

        fun parse(s: String?): Calibration? {
            if (s == null) return null
            val v = s.split(",").mapNotNull { it.toFloatOrNull() }
            if (v.size != SIZE) return null
            val c = Array(6) { i -> floatArrayOf(v[i * 3], v[i * 3 + 1], v[i * 3 + 2]) }
            return Calibration(c, v[18], v[19], v[20])
        }

        /** Примерные значения, пока калибровка не пройдена */
        val DEFAULT = Calibration(
            arrayOf(
                floatArrayOf(0f, 0f, 0.1f),      // CENTER
                floatArrayOf(0f, 0.4f, 0.05f),   // UP
                floatArrayOf(0f, -0.4f, 0.45f),  // DOWN
                floatArrayOf(-0.4f, 0f, 0.1f),   // LEFT
                floatArrayOf(0.4f, 0f, 0.1f),    // RIGHT
                floatArrayOf(0f, -0.1f, 0.85f),  // CLOSED
            ),
            1f, 1f, 1f,
        )
    }
}
