package com.example.blinkscroll

/**
 * Отличает намеренное "медленное" моргание (или взгляд вниз — веки тоже опускаются)
 * от обычного моргания, и отдельно ловит долгое закрытие глаз.
 *
 * - Закрыты от [minClosedMs] до [maxClosedMs] → [onSlowBlink] в момент открытия.
 * - Закрыты дольше [longCloseMs] → [onLongClose] сразу, не дожидаясь открытия.
 */
class BlinkDetector(
    var minClosedMs: Long = 300,
    private val maxClosedMs: Long = 1500,
    private val longCloseMs: Long = 2000,
    private val cooldownMs: Long = 700,
    private val onSlowBlink: () -> Unit,
    private val onLongClose: () -> Unit,
) {
    private var closedSince = -1L
    private var longFired = false
    private var lastTrigger = 0L

    fun update(leftOpen: Float?, rightOpen: Float?, now: Long) {
        if (leftOpen == null || rightOpen == null) {
            closedSince = -1L
            longFired = false
            return
        }
        val closed = leftOpen < CLOSED && rightOpen < CLOSED
        val open = leftOpen > OPEN && rightOpen > OPEN

        if (closed) {
            if (closedSince < 0) closedSince = now
            if (!longFired && now - closedSince >= longCloseMs) {
                longFired = true
                lastTrigger = now
                onLongClose()
            }
        } else if (open && closedSince >= 0) {
            val duration = now - closedSince
            val wasLong = longFired
            closedSince = -1L
            longFired = false
            if (!wasLong && duration in minClosedMs..maxClosedMs && now - lastTrigger > cooldownMs) {
                lastTrigger = now
                onSlowBlink()
            }
        }
        // Между порогами состояние не меняем — так меньше ложных срабатываний.
    }

    companion object {
        const val CLOSED = 0.25f
        const val OPEN = 0.6f
    }
}
