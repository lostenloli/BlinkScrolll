package com.example.blinkscroll

/**
 * Отличает намеренное "медленное" моргание от обычного.
 *
 * Обычное моргание длится ~100–150 мс, поэтому срабатываем, только если оба глаза
 * были закрыты от [minClosedMs] до [maxClosedMs]. Слишком долгое закрытие
 * (задремали, потёрли глаза) игнорируется. Срабатывание — в момент, когда глаза
 * снова открылись, чтобы вы сразу увидели новый рилс.
 */
class BlinkDetector(
    private val minClosedMs: Long = 300,
    private val maxClosedMs: Long = 1500,
    private val cooldownMs: Long = 700,
    private val onTrigger: () -> Unit,
) {
    private var closedSince = -1L
    private var lastTrigger = 0L

    fun update(leftOpen: Float?, rightOpen: Float?, now: Long) {
        if (leftOpen == null || rightOpen == null) {
            closedSince = -1L // лицо пропало — начинаем заново
            return
        }
        val closed = leftOpen < CLOSED && rightOpen < CLOSED
        val open = leftOpen > OPEN && rightOpen > OPEN

        if (closed) {
            if (closedSince < 0) closedSince = now
        } else if (open && closedSince >= 0) {
            val duration = now - closedSince
            closedSince = -1L
            if (duration in minClosedMs..maxClosedMs && now - lastTrigger > cooldownMs) {
                lastTrigger = now
                onTrigger()
            }
        }
        // Между порогами состояние не меняем — так меньше ложных срабатываний.
    }

    private companion object {
        const val CLOSED = 0.25f
        const val OPEN = 0.6f
    }
}
