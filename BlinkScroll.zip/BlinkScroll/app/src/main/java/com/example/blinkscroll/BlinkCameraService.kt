package com.example.blinkscroll

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.util.Size
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.asin
import kotlin.math.atan2

class BlinkCameraService : LifecycleService() {

    private lateinit var executor: ExecutorService
    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())

    private var landmarker: FaceLandmarker? = null
    private var analysis: ImageAnalysis? = null
    private var lastTimestamp = 0L

    private var calib = Calibration.DEFAULT
    private var loadedCalibVersion = -1

    private val eyes = EyeGestureDetector(
        onGaze = { onGaze(it) },
        onSlowBlink = { onSlowBlink() },
        onLongClose = { toggleCursorMode() },
    )
    private val head = HeadGestureDetector { onHeadGesture(it) }.apply { rollOnly = true }

    // Сглаженные признаки глаз: [горизонталь, вертикаль, закрытость]
    private val smooth = FloatArray(3)
    private var hasSmooth = false

    // Режим курсора
    private var cursorMode = false
    private var cursorBase: FloatArray? = null // pitch, yaw
    private var cx = 0f
    private var cy = 0f

    private var lastAction = 0L

    override fun onCreate() {
        super.onCreate()
        executor = Executors.newSingleThreadExecutor()
        prefs = Prefs(this)
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (landmarker == null) {
            setupLandmarker()
            startCamera()
        }
        return START_NOT_STICKY
    }

    // ---------- уведомление ----------

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, BlinkCameraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val text = if (cursorMode)
            "Курсор: двигайте головой, моргните — нажать"
        else
            "Листание: взгляд вниз/вверх/вбок, моргание"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("BlinkScroll работает")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Стоп", stop)
            .build()
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Слежение за лицом", NotificationManager.IMPORTANCE_LOW)
        )
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
    }

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---------- MediaPipe и камера ----------

    private fun setupLandmarker() {
        try {
            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("face_landmarker.task").build())
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumFaces(1)
                .setOutputFaceBlendshapes(true)
                .setOutputFacialTransformationMatrixes(true)
                .setResultListener { result, _ -> main.post { onResult(result) } }
                .setErrorListener { e -> Log.e(TAG, "MediaPipe", e) }
                .build()
            landmarker = FaceLandmarker.createFromOptions(this, options)
        } catch (e: Exception) {
            Log.e(TAG, "Не удалось загрузить модель лица", e)
            Toast.makeText(this, "Не удалось загрузить модель лица", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val a = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 360)) // мелкой картинки хватает, батарея скажет спасибо
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            a.setAnalyzer(executor, ::analyze)
            analysis = a
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, a)
            } catch (e: Exception) {
                Log.e(TAG, "Не удалось открыть фронтальную камеру", e)
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        if (lm == null) {
            proxy.close()
            return
        }
        try {
            val raw = proxy.toBitmap()
            val rotation = proxy.imageInfo.rotationDegrees
            val upright = if (rotation != 0) {
                val m = Matrix().apply { postRotate(rotation.toFloat()) }
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            } else raw
            // MediaPipe требует строго растущие отметки времени
            val ts = maxOf(SystemClock.uptimeMillis(), lastTimestamp + 1)
            lastTimestamp = ts
            lm.detectAsync(BitmapImageBuilder(upright).build(), ts)
        } catch (e: Exception) {
            Log.w(TAG, "Кадр пропущен", e)
        } finally {
            proxy.close()
        }
    }

    // ---------- логика ----------

    private fun onResult(result: FaceLandmarkerResult) {
        if (!isRunning) return
        val now = SystemClock.elapsedRealtime()

        if (LiveStatus.calibVersion != loadedCalibVersion) {
            loadedCalibVersion = LiveStatus.calibVersion
            calib = prefs.calibration()
            head.reset()
            eyes.reset()
        }
        eyes.minBlinkMs = prefs.blinkMinMs.toLong()

        val shapes = result.faceBlendshapes().orElse(null)?.firstOrNull()
        val matrix = result.facialTransformationMatrixes().orElse(null)?.firstOrNull()
        if (shapes == null || matrix == null) {
            LiveStatus.faceVisible = false
            LiveStatus.face = "Лицо не видно"
            eyes.reset()
            hasSmooth = false
            return
        }

        val score = HashMap<String, Float>()
        for (c in shapes) score[c.categoryName()] = c.score()
        fun s(name: String) = score[name] ?: 0f

        // Взгляд по горизонтали: положительный — в одну сторону, отрицательный — в другую.
        // Какая из них "лево", узнаём на калибровке, так что знак тут не важен.
        val h = ((s("eyeLookInLeft") + s("eyeLookOutRight")) -
            (s("eyeLookOutLeft") + s("eyeLookInRight"))) / 2f
        val v = (s("eyeLookUpLeft") + s("eyeLookUpRight")) / 2f -
            (s("eyeLookDownLeft") + s("eyeLookDownRight")) / 2f
        val b = (s("eyeBlinkLeft") + s("eyeBlinkRight")) / 2f

        if (!hasSmooth) {
            smooth[0] = h; smooth[1] = v; smooth[2] = b
            hasSmooth = true
        } else {
            smooth[0] += (h - smooth[0]) * 0.5f
            smooth[1] += (v - smooth[1]) * 0.5f
            smooth[2] += (b - smooth[2]) * 0.5f
        }

        val (pitch, yaw, roll) = eulerDegrees(matrix)
        LiveStatus.features = floatArrayOf(smooth[0], smooth[1], smooth[2], pitch, yaw, roll)
        LiveStatus.faceVisible = true

        val state = calib.classify(smooth)
        val yawA = yaw * calib.yawSign
        val pitchA = pitch * calib.pitchSign
        val rollA = roll * calib.rollSign

        LiveStatus.face = "Взгляд: ${stateName(state)}   Глаза закрыты: ${pct(smooth[2])}\n" +
            "Голова: поворот ${deg(yawA)}, кивок ${deg(pitchA)}, наклон ${deg(rollA)}\n" +
            "Режим: ${if (cursorMode) "курсор" else "листание"}" +
            if (prefs.hasCalibration()) "" else "\n⚠️ Калибровка не пройдена"

        if (LiveStatus.calibrating) {
            eyes.reset()
            return
        }

        eyes.update(state, now)

        val eyesClosing = smooth[2] > calib.blinkMid
        if (cursorMode && !eyesClosing) updateCursor(pitchA, yawA)
        if ((prefs.headGestures || cursorMode) && !eyesClosing) head.update(pitchA, yawA, rollA, now)
    }

    /** Углы головы в градусах из матрицы MediaPipe (4x4, по столбцам) */
    private fun eulerDegrees(m: FloatArray): Triple<Float, Float, Float> {
        fun r(row: Int, col: Int) = m[col * 4 + row]
        val pitch = atan2(r(2, 1), r(2, 2))
        val yaw = asin((-r(2, 0)).coerceIn(-1f, 1f))
        val roll = atan2(r(1, 0), r(0, 0))
        return Triple(
            Math.toDegrees(pitch.toDouble()).toFloat(),
            Math.toDegrees(yaw.toDouble()).toFloat(),
            Math.toDegrees(roll.toDouble()).toFloat(),
        )
    }

    private fun updateCursor(pitch: Float, yaw: Float) {
        val a11y = ScrollAccessibilityService.instance ?: return
        val w = a11y.screenWidth().toFloat()
        val h = a11y.screenHeight().toFloat()
        val base = cursorBase ?: floatArrayOf(pitch, yaw).also { cursorBase = it }

        // Поворот головы влево — курсор влево, подбородок вверх — курсор вверх
        val tx = (w / 2f - (yaw - base[1]) * (w / 2f) / CURSOR_YAW_RANGE).coerceIn(0f, w)
        val ty = (h / 2f - (pitch - base[0]) * (h / 2f) / CURSOR_PITCH_RANGE).coerceIn(0f, h)

        // Сглаживание, чтобы курсор не дрожал
        cx += (tx - cx) * 0.3f
        cy += (ty - cy) * 0.3f
        a11y.moveCursor(cx, cy)
    }

    /** Выполнить действие, не чаще чем раз в 600 мс */
    private fun act(name: String, block: (ScrollAccessibilityService) -> Unit) {
        val a11y = ScrollAccessibilityService.instance
        if (a11y == null) {
            LiveStatus.lastGesture = "$name — но спецвозможность выключена!"
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastAction < 600) return
        lastAction = now
        LiveStatus.lastGesture = name
        block(a11y)
        vibrate(25)
    }

    private fun onGaze(s: EyeState) {
        if (cursorMode) return // в режиме курсора глаза двигаются вместе с головой — не слушаем
        when (s) {
            EyeState.DOWN -> act("Взгляд вниз → следующее") { it.swipeUp() }
            EyeState.UP -> act("Взгляд вверх → предыдущее") { it.swipeDown() }
            EyeState.RIGHT -> act("Взгляд вправо → свайп влево") { it.swipeLeft() }
            EyeState.LEFT -> act("Взгляд влево → свайп вправо") { it.swipeRight() }
            else -> Unit
        }
    }

    private fun onSlowBlink() {
        if (cursorMode) act("Моргание → нажатие") { it.tap(cx, cy) }
        else act("Моргание → следующее") { it.swipeUp() }
    }

    private fun onHeadGesture(g: HeadGesture) {
        when (g) {
            HeadGesture.TILT_LEFT -> act("Наклон влево → Назад") { it.back() }
            HeadGesture.TILT_RIGHT -> act("Наклон вправо → Домой") { it.home() }
            else -> Unit
        }
    }

    private fun toggleCursorMode() {
        val a11y = ScrollAccessibilityService.instance
        if (a11y == null) {
            LiveStatus.lastGesture = "Режим курсора — но спецвозможность выключена!"
            return
        }
        cursorMode = !cursorMode
        head.reset()
        if (cursorMode) {
            cursorBase = null // текущая поза головы станет "центром"
            cx = a11y.screenWidth() / 2f
            cy = a11y.screenHeight() / 2f
            a11y.showCursor()
            a11y.moveCursor(cx, cy)
        } else {
            a11y.hideCursor()
        }
        LiveStatus.lastGesture = if (cursorMode) "Режим курсора" else "Режим листания"
        vibrate(if (cursorMode) 150 else 60)
        Toast.makeText(this, LiveStatus.lastGesture, Toast.LENGTH_SHORT).show()
        refreshNotification()
    }

    private fun stateName(s: EyeState) = when (s) {
        EyeState.CENTER -> "прямо"
        EyeState.UP -> "вверх"
        EyeState.DOWN -> "вниз"
        EyeState.LEFT -> "влево"
        EyeState.RIGHT -> "вправо"
        EyeState.CLOSED -> "закрыты"
    }

    private fun pct(p: Float) = "${(p * 100).toInt()}%"
    private fun deg(d: Float) = "${if (d >= 0) "+" else ""}${d.toInt()}°"

    private fun vibrate(ms: Long) {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onDestroy() {
        isRunning = false
        LiveStatus.face = "Камера выключена"
        LiveStatus.faceVisible = false
        ScrollAccessibilityService.instance?.hideCursor()
        analysis?.clearAnalyzer()
        val lm = landmarker
        landmarker = null
        // Закрываем модель в том же потоке, где обрабатываются кадры, — после последнего кадра
        executor.execute { lm?.close() }
        executor.shutdown()
        super.onDestroy() // CameraX сам отпустит камеру вместе с жизненным циклом сервиса
    }

    companion object {
        private const val TAG = "BlinkScroll"
        private const val CHANNEL = "blink"
        private const val NOTIF_ID = 1
        private const val CURSOR_YAW_RANGE = 12f
        private const val CURSOR_PITCH_RANGE = 10f
        const val ACTION_STOP = "com.example.blinkscroll.STOP"

        @Volatile
        var isRunning = false
    }
}
