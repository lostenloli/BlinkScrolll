package com.example.blinkscroll

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.util.Size
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class BlinkCameraService : LifecycleService() {

    private lateinit var executor: ExecutorService
    private lateinit var prefs: Prefs

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL) // даёт "открытость" глаз
            .setMinFaceSize(0.25f)
            .build()
    )

    private val blink = BlinkDetector(
        onSlowBlink = { onSlowBlink() },
        onLongClose = { toggleCursorMode() },
    )
    private val head = HeadGestureDetector { onHeadGesture(it) }

    // Режим курсора
    private var cursorMode = false
    private var cursorBase: FloatArray? = null // pitch, yaw
    private var cx = 0f
    private var cy = 0f

    private var lastAction = 0L

    override fun onCreate() {
        super.onCreate()
        executor = Executors.newSingleThreadExecutor()
        prefs = Prefs(this)
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        startCamera()
        return START_NOT_STICKY
    }

    // ---------- уведомление ----------

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, BlinkCameraService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val text = if (cursorMode)
            "Курсор: двигайте головой, моргните — нажать"
        else
            "Листание: моргните или опустите взгляд"
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("BlinkScroll работает")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Стоп", stop)
            .build()
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Слежение за лицом", NotificationManager.IMPORTANCE_LOW)
        )
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), type)
    }

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    // ---------- камера ----------

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 360)) // мелкой картинки хватает, батарея скажет спасибо
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { it.setAnalyzer(executor, ::analyze) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "Не удалось открыть фронтальную камеру", e)
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @OptIn(ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        val media = proxy.image ?: run { proxy.close(); return }
        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        detector.process(image)
            .addOnSuccessListener { faces -> onFace(faces.maxByOrNull { it.boundingBox.width() }) }
            .addOnCompleteListener { proxy.close() }
    }

    // ---------- логика ----------

    private fun onFace(face: Face?) {
        val now = SystemClock.elapsedRealtime()
        blink.minClosedMs = prefs.blinkMinMs.toLong()

        val left = face?.leftEyeOpenProbability
        val right = face?.rightEyeOpenProbability
        blink.update(left, right, now)
        if (face == null || left == null || right == null) return

        // Пока глаза прикрыты, голову не слушаем: моргание не должно двигать курсор
        val eyesOpen = left > BlinkDetector.OPEN && right > BlinkDetector.OPEN
        if (!eyesOpen) return

        val side = if (prefs.swapSides) -1f else 1f
        val pitch = face.headEulerAngleX
        val yaw = face.headEulerAngleY * side
        val roll = face.headEulerAngleZ * side

        if (cursorMode) {
            updateCursor(pitch, yaw)
            head.update(pitch, yaw, roll, now) // только наклоны к плечу
        } else if (prefs.headGestures) {
            head.update(pitch, yaw, roll, now)
        }
    }

    private fun updateCursor(pitch: Float, yaw: Float) {
        val a11y = ScrollAccessibilityService.instance ?: return
        val w = a11y.screenWidth().toFloat()
        val h = a11y.screenHeight().toFloat()
        val b = cursorBase ?: floatArrayOf(pitch, yaw).also { cursorBase = it }

        // ±CURSOR_YAW_RANGE градусов поворота = от края до края экрана
        val tx = (w / 2f - (yaw - b[1]) * (w / 2f) / CURSOR_YAW_RANGE).coerceIn(0f, w)
        val ty = (h / 2f - (pitch - b[0]) * (h / 2f) / CURSOR_PITCH_RANGE).coerceIn(0f, h)

        // Сглаживание, чтобы курсор не дрожал
        cx += (tx - cx) * 0.3f
        cy += (ty - cy) * 0.3f
        a11y.moveCursor(cx, cy)
    }

    /** Выполнить действие, не чаще чем раз в 600 мс */
    private fun act(block: (ScrollAccessibilityService) -> Unit) {
        val a11y = ScrollAccessibilityService.instance
        if (a11y == null) {
            Log.w(TAG, "Спецвозможность выключена — действовать нечем")
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastAction < 600) return
        lastAction = now
        block(a11y)
        vibrate(25)
    }

    private fun onSlowBlink() {
        if (cursorMode) act { it.tap(cx, cy) } else act { it.swipeUp() }
    }

    private fun onHeadGesture(g: HeadGesture) {
        when (g) {
            HeadGesture.UP -> if (!cursorMode) act { it.swipeDown() }   // предыдущее видео
            HeadGesture.LEFT -> if (!cursorMode) act { it.swipeRight() }
            HeadGesture.RIGHT -> if (!cursorMode) act { it.swipeLeft() } // следующая сторис
            HeadGesture.TILT_LEFT -> act { it.back() }
            HeadGesture.TILT_RIGHT -> act { it.home() }
            HeadGesture.DOWN -> Unit // взгляд вниз и так листает через веки
        }
    }

    private fun toggleCursorMode() {
        val a11y = ScrollAccessibilityService.instance ?: return
        cursorMode = !cursorMode
        head.reset()
        head.rollOnly = cursorMode
        if (cursorMode) {
            cursorBase = null // текущая поза головы станет "центром"
            cx = a11y.screenWidth() / 2f
            cy = a11y.screenHeight() / 2f
            a11y.showCursor()
            a11y.moveCursor(cx, cy)
        } else {
            a11y.hideCursor()
        }
        vibrate(if (cursorMode) 120 else 60)
        Toast.makeText(
            this,
            if (cursorMode) "Режим курсора" else "Режим листания",
            Toast.LENGTH_SHORT,
        ).show()
        refreshNotification()
    }

    private fun vibrate(ms: Long) {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onDestroy() {
        isRunning = false
        ScrollAccessibilityService.instance?.hideCursor()
        detector.close()
        executor.shutdown()
        super.onDestroy() // CameraX сам отпустит камеру вместе с жизненным циклом сервиса
    }

    companion object {
        private const val TAG = "BlinkScroll"
        private const val CHANNEL = "blink"
        private const val NOTIF_ID = 1
        private const val CURSOR_YAW_RANGE = 15f
        private const val CURSOR_PITCH_RANGE = 12f
        const val ACTION_STOP = "com.example.blinkscroll.STOP"

        @Volatile
        var isRunning = false
    }
}
